"use client";
const Error = () => {
  return (
    //The error layout
    <div>Error</div>
  );
};

export default Error;
